package zen.users.enums;

public enum TiposAssinatura {
	PLANO_FREE,
	PLANO_1,
	PLANO_2,
	PLANO_3,
	PLANO_4
}
