package zen.users;

public class Administrador extends Usuario {
	// Banir usuario
	// Bloquear usuario
}
